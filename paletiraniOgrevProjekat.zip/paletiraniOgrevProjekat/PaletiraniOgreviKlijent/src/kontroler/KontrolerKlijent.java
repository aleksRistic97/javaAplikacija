/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kontroler;

import domen.Kupac;
import domen.Proizvod;
import domen.Racun;
import domen.Sirovina;
import domen.StavkaProizvoda;
import domen.Zaposleni;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import sesije.Sesija;
import transfer.Zahtev;
import transfer.Odgovor;
import operacije.VrstaOdgovora;
import operacije.Operacije;

/**
 *
 * @author PC
 */
public class KontrolerKlijent {

    private static KontrolerKlijent instance;

    private KontrolerKlijent() {
    }

    public static KontrolerKlijent getInstance() {
        if (instance == null) {
            instance = new KontrolerKlijent();
        }
        return instance;
    }

    public Zaposleni login(Zaposleni zaposleni) throws Exception {
        return (Zaposleni) posaljiZahtev(Operacije.LOGIN, zaposleni);
    }

    public void logout(Zaposleni ulogovani) throws Exception {
        posaljiZahtev(Operacije.LOGOUT, ulogovani);
    }

    public void addKupac(Kupac kupac) throws Exception {
        posaljiZahtev(Operacije.DODAJ_KUPCA, kupac);
    }

    public void addProizvod(Proizvod proizvod) throws Exception {
        posaljiZahtev(Operacije.DODAJ_PROIZVOD, proizvod);
    }

    public void addRacun(Racun racun) throws Exception {
        posaljiZahtev(Operacije.DODAJ_RACUN, racun);
    }

    public void deleteKupac(Kupac kupac) throws Exception {
        posaljiZahtev(Operacije.OBRISI_KUPCA, kupac);
    }

    public void deleteProizvod(Proizvod proizvod) throws Exception {
        posaljiZahtev(Operacije.OBRISI_PROIZVOD, proizvod);
    }

    public void updateKupac(Kupac kupac) throws Exception {
        posaljiZahtev(Operacije.IZMENI_KUPCA, kupac);
    }

    public void updateProizvod(Proizvod proizvod) throws Exception {
        posaljiZahtev(Operacije.IZMENI_PROIZVOD, proizvod);
    }

    public ArrayList<Kupac> getAllKupac() throws Exception {
        return (ArrayList<Kupac>) posaljiZahtev(Operacije.VRATI_SVE_KUPCE, null);
    }

    public ArrayList<Proizvod> getAllProizvod() throws Exception {
        return (ArrayList<Proizvod>) posaljiZahtev(Operacije.VRATI_SVE_PROIZVODE, null);
    }

    public ArrayList<Sirovina> getAllSirovina() throws Exception {
        return (ArrayList<Sirovina>) posaljiZahtev(Operacije.VRATI_SVE_SIROVINE, null);
    }
    
    public ArrayList<StavkaProizvoda> getAllSirovine(Proizvod p) throws Exception {
         return (ArrayList<StavkaProizvoda>) posaljiZahtev(Operacije.VRATI_SVE_SIAVKE_PROIZVODA, p);
    }

    private Object posaljiZahtev(int operacija, Object objekat) throws Exception {
        Zahtev zahtev = new Zahtev(operacija, objekat);

        ObjectOutputStream out = new ObjectOutputStream(Sesija.getInstance().getSocket().getOutputStream());
        out.writeObject(zahtev);

        ObjectInputStream in = new ObjectInputStream(Sesija.getInstance().getSocket().getInputStream());
        Odgovor odgovor = (Odgovor) in.readObject();

        if (odgovor.getVrstaOdgovora().equals(VrstaOdgovora.Greska)) {
            throw odgovor.getGreska();
        } else {
            return odgovor.getObjekat();
        }

    }

   

}
