/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeliTabela;

import kontroler.KontrolerKlijent;
import domen.Proizvod;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author PC
 */
public class ModelTabeleProizvodi extends AbstractTableModel implements Runnable {

    private ArrayList<Proizvod> lista;
    private String[] kolone = {"ID", "Naziv", "Cena po komadu", "Jedinica mere"};
    private String parametar = "";

    public ModelTabeleProizvodi() {
        try {
            lista = KontrolerKlijent.getInstance().getAllProizvod();
        } catch (Exception ex) {
            Logger.getLogger(ModelTabeleProizvodi.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public int getRowCount() {
        return lista.size();
    }

    @Override
    public int getColumnCount() {
        return kolone.length;
    }

    @Override
    public String getColumnName(int i) {
        return kolone[i];
    }

    @Override
    public Object getValueAt(int row, int column) {
        Proizvod p = lista.get(row);

        switch (column) {
            case 0:
                return p.getProizvodID();
            case 1:
                return p.getNaziv();
            case 2:
                return p.getCenaPoKomadu() + "din";
            case 3:
                return p.getJedinicaMere();

            default:
                return null;
        }
    }

    public Proizvod getSelectedProizvod(int row) {
        return lista.get(row);
    }

    @Override
    public void run() {
        try {
            while (!Thread.currentThread().isInterrupted()) {
                Thread.sleep(10000);
                refreshTable();
            }
        } catch (InterruptedException ex) {
            Logger.getLogger(ModelTabeleProizvodi.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void setParametar(String parametar) {
        this.parametar = parametar;
        refreshTable();
    }

    public void refreshTable() {
        try {
            lista = KontrolerKlijent.getInstance().getAllProizvod();
            if (!parametar.equals("")) {
                ArrayList<Proizvod> novaLista = new ArrayList<>();
                for (Proizvod p : lista) {
                    if (p.getNaziv().toLowerCase().contains(parametar.toLowerCase())) {
                        novaLista.add(p);
                    }
                }
                lista = novaLista;
            }

            fireTableDataChanged();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

}
