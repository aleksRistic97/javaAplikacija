/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeliTabela;

import domen.Sirovina;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.AbstractTableModel;


/**
 *
 * @author PC
 */
public class ModelTabeleSirovine extends AbstractTableModel {

    private ArrayList<Sirovina> lista;
    private String[] kolone = { "Naziv", "Tip obrade"};
 

    public ModelTabeleSirovine() {
        lista = new ArrayList<>();
    }

    public ModelTabeleSirovine(ArrayList<Sirovina> sirovine) {
        try {
            lista=sirovine;
           
        } catch (Exception ex) {
            Logger.getLogger(ModelTabeleSirovine.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public int getRowCount() {
        return lista.size();
    }

    @Override
    public int getColumnCount() {
        return kolone.length;
    }

    @Override
    public String getColumnName(int i) {
        return kolone[i];
    }

    @Override
    public Object getValueAt(int row, int column) {
        Sirovina s = lista.get(row);

        switch (column) {
       
            case 0:
                return s.getNaziv();
            case 1:
                return s.getTipObrade();

            default:
                return null;
        }
    }

    public void dodajSirovinu(Sirovina sirovina) {
  
        lista.add(sirovina);
        fireTableDataChanged();
    }

    public void obrisiSirovinu(int row) {
        lista.remove(row);
        fireTableDataChanged();
    }

    public ArrayList<Sirovina> getLista() {
        return lista;
    }

    public void setLista(ArrayList<Sirovina> sirovine) {
        lista=sirovine;
        fireTableDataChanged();
    }

}
