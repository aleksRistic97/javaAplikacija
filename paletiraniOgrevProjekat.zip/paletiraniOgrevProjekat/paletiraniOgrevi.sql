/*
SQLyog Community v13.1.6 (64 bit)
MySQL - 10.4.18-MariaDB : Database - database
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`paletiraniOgrevi` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci */;

USE `paletiraniOgrevi`;



DROP TABLE IF EXISTS `Zaposleni`;

CREATE TABLE `Zaposleni` (
  `ZaposleniID` BIGINT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `Ime` VARCHAR(30) NOT NULL,
  `Prezime` VARCHAR(30) NOT NULL,
  `Username` VARCHAR(30) NOT NULL,
  `Password` VARCHAR(30) NOT NULL,
  PRIMARY KEY (`ZaposleniID`)
) ENGINE=INNODB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;



INSERT  INTO `Zaposleni` VALUES 
(1,'Aleksandra','Ristic','aleks','aleks'),
(2,'Srdjan','Ristic','srki','srki');



DROP TABLE IF EXISTS `Kupac`;

CREATE TABLE `Kupac` (
  `KupacID` BIGINT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `PIB` VARCHAR(11) NOT NULL,
  `MaticniBroj` VARCHAR(15) NOT NULL,
  `Naziv` VARCHAR(50) NOT NULL,
  `Adresa` VARCHAR(50) NOT NULL,
  `BrojTelefona` VARCHAR(30) NOT NULL,
  PRIMARY KEY (`KupacID`)
) ENGINE=INNODB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;



INSERT  INTO `Kupac` VALUES 
(1,'2738271829', '7322637282','Stovariste Jovanovic', '27. Marta 84', '0631231234'),
(2,'7283726212', '9872635478','Stovariste Petrovic', 'Milutina Milankovica 12', '0642637263');


DROP TABLE IF EXISTS `Proizvod`;

CREATE TABLE `Proizvod` (
  `ProizvodID` BIGINT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `Naziv` VARCHAR(50) COLLATE utf8_unicode_ci NOT NULL,
  `Opis` VARCHAR(200) COLLATE utf8_unicode_ci NOT NULL,
  `CenaPoKomadu` DECIMAL(10,2) NOT NULL,
  `JedinicaMere` VARCHAR(5) NOT NULL,
  PRIMARY KEY (`ProizvodID`)
) ENGINE=INNODB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



INSERT  INTO `Proizvod` VALUES 
(1,'Ogrevno drvo','Ogrevno drvo od 25cm.',10000,'komad'),
(2,'Greda','Greda 10x10x4.',15000,'kbm'),
(3,'Daska','Cola 4m.',15000,'kbm');


DROP TABLE IF EXISTS `Sirovina`;

CREATE TABLE `Sirovina` (
  `ProizvodID` BIGINT(10) UNSIGNED NOT NULL,
  `Rb` INT(7) NOT NULL,
  `Naziv` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`ProizvodID`,`Rb`),
  CONSTRAINT `fk_proizvod_id` FOREIGN KEY (`ProizvodID`) REFERENCES `Proizvod` (`ProizvodID`) ON DELETE CASCADE
) ENGINE=INNODB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;



INSERT  INTO `Sirovina` VALUES 
(1,1,'Bukva'),
(1,2,'Cer'),
(2,1,'Jela'),
(2,2,'Smrca'),
(3,1,'Jela'),
(3,2,'Smrca');




DROP TABLE IF EXISTS `Racun`;

CREATE TABLE `Racun` (
  `RacunID` BIGINT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `DatumVreme` DATETIME NOT NULL,
  `CenaBezPDV` DECIMAL(10,2) NOT NULL,
  `PDV` DECIMAL(10,2) NOT NULL,
  `CenaSaPDV` DECIMAL(10,2) NOT NULL,
  `KupacID` BIGINT(10) UNSIGNED NOT NULL,
  `ZaposleniID` BIGINT(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`RacunID`),
  CONSTRAINT `fk2_zaposleni_id` FOREIGN KEY (`ZaposleniID`) REFERENCES `Zaposleni` (`ZaposleniID`),
  CONSTRAINT `fk2_kupac_id` FOREIGN KEY (`KupacID`) REFERENCES `Kupac` (`KupacID`)
) ENGINE=INNODB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


INSERT  INTO `Racun` VALUES 
(1,'2023-12-15 19:00:00',25000,20,30000,1,1);


DROP TABLE IF EXISTS `StavkaRacuna`;

CREATE TABLE `StavkaRacuna` (
  `RacunID` BIGINT(10) UNSIGNED NOT NULL,
  `Rb` INT NOT NULL,
  `Kolicina` INT(7) NOT NULL,
  `Cena` DECIMAL(10,2) UNSIGNED NOT NULL,
  `ProizvodID` BIGINT(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`RacunID`,`Rb`),
  CONSTRAINT `fk_racun_id` FOREIGN KEY (`RacunID`) REFERENCES `Racun` (`RacunID`) ON DELETE CASCADE,
  CONSTRAINT `fk2_proizvod_id` FOREIGN KEY (`ProizvodID`) REFERENCES `Proizvod` (`ProizvodID`)
) ENGINE=INNODB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



INSERT  INTO `StavkaRacuna` VALUES 
(1,1,1,10000,1),
(1,2,1,15000,2);




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
