/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package operacije;

/**
 *
 * @author PC
 */
public interface Operacije {

    public static final int LOGIN = 0;
    public static final int LOGOUT = 1;

    public static final int DODAJ_KUPCA = 2;
    public static final int OBRISI_KUPCA = 3;
    public static final int IZMENI_KUPCA = 4;
    public static final int VRATI_SVE_KUPCE = 5;

    public static final int DODAJ_PROIZVOD = 6;
    public static final int OBRISI_PROIZVOD = 7;
    public static final int IZMENI_PROIZVOD = 8;
    public static final int VRATI_SVE_PROIZVODE = 9;

    public static final int VRATI_SVE_SIROVINE = 10;

    public static final int DODAJ_RACUN = 11;
    public static final int VRAT_SVE_RACUNE = 12;

    public static final int VRATI_SVE_STAVKE_RACUNA = 13;
    public static final int VRATI_SVE_SIAVKE_PROIZVODA= 14;

}
