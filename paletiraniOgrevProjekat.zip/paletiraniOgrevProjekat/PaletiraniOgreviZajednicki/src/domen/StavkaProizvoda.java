/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domen;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author ognje
 */
public class StavkaProizvoda extends AbstractDomainObject {

    private int rb;
    private Sirovina sirovina;
    private Proizvod proizvod;

    public StavkaProizvoda() {
    }

    public StavkaProizvoda(int rb, Sirovina sirovina, Proizvod proizvod) {
        this.rb = rb;
        this.sirovina = sirovina;
        this.proizvod = proizvod;
    }

    public int getRb() {
        return rb;
    }

    public void setRb(int rb) {
        this.rb = rb;
    }

    @Override
    public String nazivTabele() {
        return " stavkaProizvoda ";
    }

    @Override
    public String alias() {
        return " sp ";
    }

    @Override
    public String join() {
        return " JOIN proizvod p ON (sp.proizvodID=p.proizvodID)"
                + " JOIN sirovina s ON (s.sirovinaID=sp.sirovinaID)";
    }

    @Override
    public ArrayList<AbstractDomainObject> vratiListu(ResultSet rs) throws SQLException {
        ArrayList<AbstractDomainObject> lista = new ArrayList<>();

        while (rs.next()) {

            Proizvod p = new Proizvod(rs.getLong("ProizvodID"), rs.getString("p.Naziv"), rs.getString("p.Opis"),
                    rs.getDouble("CenaPoKomadu"), rs.getString("JedinicaMere"), null);

            Sirovina s = new Sirovina(rs.getInt("SirovinaID"), rs.getString("s.Naziv"),
                    rs.getString("s.Opis"), rs.getString("TipObrade"));

            StavkaProizvoda sp = new StavkaProizvoda(rs.getInt("rb"), s, p);

            lista.add(sp);
        }

        rs.close();
        return lista;
    }

    @Override
    public String koloneInsert() {
        return " (ProizvodID, Rb, SirovinaID) ";
    }

    @Override
    public String uslov() {
        return " ProizvodID = " + proizvod.getProizvodID();
    }

    @Override
    public String vrednostiDodaj() {
        return proizvod.getProizvodID() + ", " + rb + ", " + sirovina.getSirovinaID();
    }

    @Override
    public String vrednostiAzuriraj() {
        return "";
    }

    @Override
    public String uslovPrikazi() {
        return " WHERE sp.proizvodID="+proizvod.getProizvodID();
    }

    public Sirovina getSirovina() {
        return sirovina;
    }

    public void setSirovina(Sirovina sirovina) {
        this.sirovina = sirovina;
    }

    public Proizvod getProizvod() {
        return proizvod;
    }

    public void setProizvod(Proizvod proizvod) {
        this.proizvod = proizvod;
    }

    @Override
    public String toString() {
        return "rb: "+rb+" sirovina: "+sirovina.getNaziv()+" proizvod: "+proizvod.getNaziv();
    }

    
}
