/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domen;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author PC
 */
public class Proizvod extends AbstractDomainObject {
    
    private Long proizvodID;
    private String naziv;
    private String opis;
    private double cenaPoKomadu;
    private String jedinicaMere;
    private ArrayList<StavkaProizvoda> stavkeProizvoda;

    @Override
    public String toString() {
        return naziv + " (Cena po komadu: " + cenaPoKomadu + "din, "
                + "Jedinica mere: " + jedinicaMere + ")";
    }

    public Proizvod(Long proizvodID, String naziv, String opis, double cenaPoKomadu, String jedinicaMere, ArrayList<StavkaProizvoda> stavkeProizvoda) {
        this.proizvodID = proizvodID;
        this.naziv = naziv;
        this.opis = opis;
        this.cenaPoKomadu = cenaPoKomadu;
        this.jedinicaMere = jedinicaMere;
        this.stavkeProizvoda = stavkeProizvoda;
    }

    

    public Proizvod() {
    }
    
    @Override
    public String nazivTabele() {
        return " proizvod ";
    }

    @Override
    public String alias() {
        return " p ";
    }

    @Override
    public String join() {
        return "";
    }

    @Override
    public ArrayList<AbstractDomainObject> vratiListu(ResultSet rs) throws SQLException {
        ArrayList<AbstractDomainObject> lista = new ArrayList<>();

        while (rs.next()) {
            Proizvod p = new Proizvod(rs.getLong("ProizvodID"),
                    rs.getString("Naziv"), rs.getString("Opis"),
                    rs.getDouble("CenaPoKomadu"), rs.getString("JedinicaMere"), null);

            lista.add(p);
        }

        rs.close();
        return lista;
    }

    @Override
    public String koloneInsert() {
        return " (Naziv, Opis, CenaPoKomadu, JedinicaMere) ";
    }

    @Override
    public String uslov() {
        return " ProizvodID = " + proizvodID;
    }

    @Override
    public String vrednostiDodaj() {
        return "'" + naziv + "', '" + opis + "', "
                + cenaPoKomadu + ", '" + jedinicaMere + "'";
    }

    @Override
    public String vrednostiAzuriraj() {
        return "CenaPoKomadu = " + cenaPoKomadu;
    }

    @Override
    public String uslovPrikazi() {
        return "";
    }

    public Long getProizvodID() {
        return proizvodID;
    }

    public void setProizvodID(Long proizvodID) {
        this.proizvodID = proizvodID;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    public double getCenaPoKomadu() {
        return cenaPoKomadu;
    }

    public void setCenaPoKomadu(double cenaPoKomadu) {
        this.cenaPoKomadu = cenaPoKomadu;
    }

    public String getJedinicaMere() {
        return jedinicaMere;
    }

    public void setJedinicaMere(String jedinicaMere) {
        this.jedinicaMere = jedinicaMere;
    }

    public ArrayList<StavkaProizvoda> getStavkeProizvoda() {
        return stavkeProizvoda;
    }

    public void setStavkeProizvoda(ArrayList<StavkaProizvoda> stavkeProizvoda) {
        this.stavkeProizvoda = stavkeProizvoda;
    }

    
}
