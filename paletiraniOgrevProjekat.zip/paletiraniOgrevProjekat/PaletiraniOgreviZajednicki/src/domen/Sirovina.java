/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domen;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author PC
 */
public class Sirovina extends AbstractDomainObject {
    
    private int sirovinaID;
    private String naziv;
    private String opis;
    private String tipObrade;

    public Sirovina(int sirovinaID, String naziv, String opis, String tipObrade) {
        this.sirovinaID = sirovinaID;
        this.naziv = naziv;
        this.opis = opis;
        this.tipObrade = tipObrade;
    }

    public Sirovina() {
    }
    
    
    @Override
    public String nazivTabele() {
        return " sirovina ";
    }

    @Override
    public String alias() {
        return " s ";
    }

    @Override
    public String join() {
        return "";
    }

    @Override
    public ArrayList<AbstractDomainObject> vratiListu(ResultSet rs) throws SQLException {
        ArrayList<AbstractDomainObject> lista = new ArrayList<>();

        while (rs.next()) {
            
            
           Sirovina s=new Sirovina(rs.getInt("SirovinaID"), rs.getString("Naziv"), 
                   rs.getString("Opis"), rs.getString("TipObrade"));
                  

            lista.add(s);
        }

        rs.close();
        return lista;
    }

    @Override
    public String koloneInsert() {
        return " (SirovinaID, Naziv, Opis, TipObrade) ";
    }

    @Override
    public String uslov() {
        return " SirovinaID = " + sirovinaID;
    }

    @Override
    public String vrednostiDodaj() {
        return sirovinaID + ", '" + naziv + "', "
                + "'" + opis + "', '"+tipObrade+"' ";
    }

    @Override
    public String vrednostiAzuriraj() {
        return "";
    }

    @Override
    public String uslovPrikazi() {
        return "";
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public int getSirovinaID() {
        return sirovinaID;
    }

    public String getOpis() {
        return opis;
    }

    public String getTipObrade() {
        return tipObrade;
    }

    public void setSirovinaID(int sirovinaID) {
        this.sirovinaID = sirovinaID;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    public void setTipObrade(String tipObrade) {
        this.tipObrade = tipObrade;
    }

    @Override
    public String toString() {
        return naziv;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Sirovina other = (Sirovina) obj;
        return this.sirovinaID == other.sirovinaID;
    }
    
}
