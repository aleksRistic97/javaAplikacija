/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domen;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author PC
 */
public class Racun extends AbstractDomainObject {
    
    private Long racunID;
    private Date datumVreme;
    private double cenaBezPDV;
    private double PDV;
    private double cenaSaPDV;
    private Kupac kupac;
    private Zaposleni zaposleni;
    private ArrayList<StavkaRacuna> stavkeRacuna;

    public Racun(Long racunID, Date datumVreme, double cenaBezPDV, double PDV, double cenaSaPDV, Kupac kupac, Zaposleni zaposleni, ArrayList<StavkaRacuna> stavkeRacuna) {
        this.racunID = racunID;
        this.datumVreme = datumVreme;
        this.cenaBezPDV = cenaBezPDV;
        this.PDV = PDV;
        this.cenaSaPDV = cenaSaPDV;
        this.kupac = kupac;
        this.zaposleni = zaposleni;
        this.stavkeRacuna = stavkeRacuna;
    }

    public Racun() {
    }
    
    @Override
    public String nazivTabele() {
        return " racun ";
    }

    @Override
    public String alias() {
        return " r ";
    }

    @Override
    public String join() {
        return " JOIN kupac k ON (k.kupacid = r.kupacid) "
                + "JOIN zaposleni z ON (z.zaposleniid = r.zaposleniid) ";
    }

    @Override
    public ArrayList<AbstractDomainObject> vratiListu(ResultSet rs) throws SQLException {
        ArrayList<AbstractDomainObject> lista = new ArrayList<>();

        while (rs.next()) {
            Zaposleni z = new Zaposleni(rs.getLong("ZaposleniID"),
                    rs.getString("Ime"), rs.getString("Prezime"),
                    rs.getString("Username"), rs.getString("Password"));
            
            Kupac k = new Kupac(rs.getLong("KupacID"),
                    rs.getString("PIB"), rs.getString("MaticniBroj"),
                    rs.getString("Naziv"), rs.getString("Adresa"),
                    rs.getString("BrojTelefona"));
            
            Racun r = new Racun(rs.getLong("RacunID"), rs.getTimestamp("DatumVreme"), 
                    rs.getDouble("CenaBezPDV"), rs.getDouble("PDV"), 
                    rs.getDouble("CenaSaPDV"), k, z, null);

            lista.add(r);
        }

        rs.close();
        return lista;
    }

    @Override
    public String koloneInsert() {
        return " (DatumVreme, CenaBezPDV, PDV, CenaSaPDV, KupacID, ZaposleniID) ";
    }

    @Override
    public String uslov() {
        return " RacunID = " + racunID;
    }

    @Override
    public String vrednostiDodaj() {
        return "'" + new Timestamp(datumVreme.getTime()) + "', " + cenaBezPDV + ", "
                + PDV + ", " + cenaSaPDV + ", " + kupac.getKupacID() + ", "
                + zaposleni.getZaposleniID();
    }

    @Override
    public String vrednostiAzuriraj() {
        return "";
    }

    @Override
    public String uslovPrikazi() {
        return "";
    }

    public Long getRacunID() {
        return racunID;
    }

    public void setRacunID(Long racunID) {
        this.racunID = racunID;
    }

    public Date getDatumVreme() {
        return datumVreme;
    }

    public void setDatumVreme(Date datumVreme) {
        this.datumVreme = datumVreme;
    }

    public double getCenaBezPDV() {
        return cenaBezPDV;
    }

    public void setCenaBezPDV(double cenaBezPDV) {
        this.cenaBezPDV = cenaBezPDV;
    }

    public double getPDV() {
        return PDV;
    }

    public void setPDV(double PDV) {
        this.PDV = PDV;
    }

    public double getCenaSaPDV() {
        return cenaSaPDV;
    }

    public void setCenaSaPDV(double cenaSaPDV) {
        this.cenaSaPDV = cenaSaPDV;
    }

    public Kupac getKupac() {
        return kupac;
    }

    public void setKupac(Kupac kupac) {
        this.kupac = kupac;
    }

    public Zaposleni getZaposleni() {
        return zaposleni;
    }

    public void setZaposleni(Zaposleni zaposleni) {
        this.zaposleni = zaposleni;
    }

    public ArrayList<StavkaRacuna> getStavkeRacuna() {
        return stavkeRacuna;
    }

    public void setStavkeRacuna(ArrayList<StavkaRacuna> stavkeRacuna) {
        this.stavkeRacuna = stavkeRacuna;
    }
}
