/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domen;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author PC
 */
public class Kupac extends AbstractDomainObject {
    
    private Long kupacID;
    private String PIB;
    private String maticniBroj;
    private String naziv;
    private String adresa;
    private String brojTelefona;

    public Kupac() {
    }

    public Kupac(Long kupacID, String PIB, String maticniBroj, String naziv, String adresa, String brojTelefona) {
        this.kupacID = kupacID;
        this.PIB = PIB;
        this.maticniBroj = maticniBroj;
        this.naziv = naziv;
        this.adresa = adresa;
        this.brojTelefona = brojTelefona;
    }

    @Override
    public String toString() {
        return naziv;
    }
    
    @Override
    public String nazivTabele() {
        return " kupac ";
    }

    @Override
    public String alias() {
        return " k ";
    }

    @Override
    public String join() {
        return "";
    }

    @Override
    public ArrayList<AbstractDomainObject> vratiListu(ResultSet rs) throws SQLException {
        ArrayList<AbstractDomainObject> lista = new ArrayList<>();

        while (rs.next()) {
            Kupac k = new Kupac(rs.getLong("KupacID"),
                    rs.getString("PIB"), rs.getString("MaticniBroj"),
                    rs.getString("Naziv"), rs.getString("Adresa"),
                    rs.getString("BrojTelefona"));

            lista.add(k);
        }

        rs.close();
        return lista;
    }

    @Override
    public String koloneInsert() {
        return " (PIB, MaticniBroj, Naziv, Adresa, BrojTelefona) ";
    }

    @Override
    public String uslov() {
        return " KupacID = " + kupacID;
    }

    @Override
    public String vrednostiDodaj() {
        return "'" + PIB + "', '" + maticniBroj + "', "
                + "'" + naziv + "', '" + adresa + "', '" + brojTelefona + "'";
    }

    @Override
    public String vrednostiAzuriraj() {
        return "Adresa = '" + adresa + "', BrojTelefona = '" + brojTelefona + "'";
    }

    @Override
    public String uslovPrikazi() {
        return "";
    }

    public Long getKupacID() {
        return kupacID;
    }

    public void setKupacID(Long kupacID) {
        this.kupacID = kupacID;
    }

    public String getPIB() {
        return PIB;
    }

    public void setPIB(String PIB) {
        this.PIB = PIB;
    }

    public String getMaticniBroj() {
        return maticniBroj;
    }

    public void setMaticniBroj(String maticniBroj) {
        this.maticniBroj = maticniBroj;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getAdresa() {
        return adresa;
    }

    public void setAdresa(String adresa) {
        this.adresa = adresa;
    }

    public String getBrojTelefona() {
        return brojTelefona;
    }

    public void setBrojTelefona(String brojTelefona) {
        this.brojTelefona = brojTelefona;
    }
}
