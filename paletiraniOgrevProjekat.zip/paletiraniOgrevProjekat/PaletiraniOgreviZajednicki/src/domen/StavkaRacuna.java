/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domen;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author PC
 */
public class StavkaRacuna extends AbstractDomainObject {

    private Racun racun;
    private int rb;
    private int kolicina;
    private double cena;
    private Proizvod proizvod;

    public StavkaRacuna(Racun racun, int rb, int kolicina, double cena, Proizvod proizvod) {
        this.racun = racun;
        this.rb = rb;
        this.kolicina = kolicina;
        this.cena = cena;
        this.proizvod = proizvod;
    }

    public StavkaRacuna() {
    }

    @Override
    public String nazivTabele() {
        return " stavkaRacuna ";
    }

    @Override
    public String alias() {
        return " sr ";
    }

    @Override
    public String join() {
        return " JOIN racun r ON (r.racunid = sr.racunid) "
                + "JOIN kupac k ON (k.kupacid = r.kupacid) "
                + "JOIN zaposleni z ON (z.zaposleniid = r.zaposleniid) "
                + "JOIN proizvod p ON (sr.proizvodid = p.proizvodid) ";
    }

    @Override
    public ArrayList<AbstractDomainObject> vratiListu(ResultSet rs) throws SQLException {
        ArrayList<AbstractDomainObject> lista = new ArrayList<>();

        while (rs.next()) {
            Zaposleni z = new Zaposleni(rs.getLong("ZaposleniID"),
                    rs.getString("Ime"), rs.getString("Prezime"),
                    rs.getString("Username"), rs.getString("Password"));
            
            Kupac k = new Kupac(rs.getLong("KupacID"),
                    rs.getString("PIB"), rs.getString("MaticniBroj"),
                    rs.getString("k.Naziv"), rs.getString("Adresa"),
                    rs.getString("BrojTelefona"));
            
            Racun r = new Racun(rs.getLong("RacunID"), rs.getTimestamp("DatumVreme"), 
                    rs.getDouble("CenaBezPDV"), rs.getDouble("PDV"), 
                    rs.getDouble("CenaSaPDV"), k, z, null);
            
            Proizvod p = new Proizvod(rs.getLong("ProizvodID"),
                    rs.getString("p.Naziv"), rs.getString("Opis"),
                    rs.getDouble("CenaPoKomadu"), rs.getString("JedinicaMere"), null);
            
            StavkaRacuna sr = new StavkaRacuna(r, rs.getInt("Rb"), 
                    rs.getInt("Kolicina"), rs.getDouble("Cena"), p);
            lista.add(sr);
        }

        rs.close();
        return lista;
    }

    @Override
    public String koloneInsert() {
        return " (RacunID, Rb, Kolicina, Cena, ProizvodID) ";
    }

    @Override
    public String uslov() {
        return " RacunID = " + racun.getRacunID();
    }

    @Override
    public String vrednostiDodaj() {
        return racun.getRacunID() + ", " + rb + ", "
                + kolicina + ", " + cena + ", " + proizvod.getProizvodID();
    }

    @Override
    public String vrednostiAzuriraj() {
        return "";
    }

    @Override
    public String uslovPrikazi() {
        return " WHERE r.racunid = " + racun.getRacunID();
    }

    public Racun getRacun() {
        return racun;
    }

    public void setRacun(Racun racun) {
        this.racun = racun;
    }

    public int getRb() {
        return rb;
    }

    public void setRb(int rb) {
        this.rb = rb;
    }

    public int getKolicina() {
        return kolicina;
    }

    public void setKolicina(int kolicina) {
        this.kolicina = kolicina;
    }

    public double getCena() {
        return cena;
    }

    public void setCena(double cena) {
        this.cena = cena;
    }

    public Proizvod getProizvod() {
        return proizvod;
    }

    public void setProizvod(Proizvod proizvod) {
        this.proizvod = proizvod;
    }
}
