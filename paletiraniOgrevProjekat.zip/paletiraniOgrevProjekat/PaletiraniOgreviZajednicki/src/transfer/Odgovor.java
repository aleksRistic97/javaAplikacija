/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package transfer;

import java.io.Serializable;
import operacije.VrstaOdgovora;

/**
 *
 * @author PC
 */
public class Odgovor implements Serializable {

    private Object objekat;
    private Exception greska;
    private VrstaOdgovora odgovor;

    public Odgovor() {
    }

    public Odgovor(Object objekat, Exception greska, VrstaOdgovora odgovor) {
        this.objekat = objekat;
        this.greska = greska;
        this.odgovor = odgovor;
    }

    public Object getObjekat() {
        return objekat;
    }

    public void setObjekat(Object objekat) {
        this.objekat = objekat;
    }

    public Exception getGreska() {
        return greska;
    }

    public void setGreska(Exception greska) {
        this.greska = greska;
    }

    public VrstaOdgovora getVrstaOdgovora() {
        return odgovor;
    }

    public void setVrstaOdgovora(VrstaOdgovora odgovor) {
        this.odgovor = odgovor;
    }

}
