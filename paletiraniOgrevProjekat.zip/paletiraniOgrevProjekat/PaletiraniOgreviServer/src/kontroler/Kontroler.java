/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kontroler;

import domen.Kupac;
import domen.Proizvod;
import domen.Racun;
import domen.Sirovina;
import domen.StavkaProizvoda;
import domen.Zaposleni;
import java.util.ArrayList;
import so.kupac.DodajKupcaSO;
import so.kupac.ObrisiKupcaSO;
import so.kupac.VratiKupceSO;
import so.kupac.IzmeniKupcaSO;
import so.login.LoginSO;
import so.proizvod.DodajProizvodSO;
import so.proizvod.ObrisiProizvodSO;
import so.proizvod.VratiProizvodeSO;
import so.proizvod.IzmeniProizvodSO;
import so.racun.DodajRacunSO;
import so.sirovina.VratiSirovineSO;
import so.stavkeProizvoda.VratiStavkeProizvodaSO;

/**
 *
 * @author PC
 */
public class Kontroler {

    private static Kontroler instance;
    private ArrayList<Zaposleni> ulogovaniZaposleni = new ArrayList<>();

    private Kontroler() {
    }

    public static Kontroler getInstance() {
        if (instance == null) {
            instance = new Kontroler();
        }
        return instance;
    }

    public ArrayList<Zaposleni> vratiUlogovanogZaposlenog() {
        return ulogovaniZaposleni;
    }

    public void postaviUlogovanogZaposlenog(ArrayList<Zaposleni> ulogovaniZaposleni) {
        this.ulogovaniZaposleni = ulogovaniZaposleni;
    }

    public Zaposleni login(Zaposleni zaposleni) throws Exception {
        LoginSO so = new LoginSO();
        so.run(zaposleni);
        return so.getUlogovani();
    }

    public void dodajKupca(Kupac kupac) throws Exception {
        (new DodajKupcaSO()).run(kupac);
    }

    public void dodajProizvod(Proizvod proizvod) throws Exception {
        (new DodajProizvodSO()).run(proizvod);
    }

    public void dodajRacun(Racun racun) throws Exception {
        (new DodajRacunSO()).run(racun);
    }

    public void obrisiKupca(Kupac kupac) throws Exception {
        (new ObrisiKupcaSO()).run(kupac);
    }

    public void obrisiProizvod(Proizvod proizvod) throws Exception {
        (new ObrisiProizvodSO()).run(proizvod);
    }

    public void izmeniKupca(Kupac kupac) throws Exception {
        (new IzmeniKupcaSO()).run(kupac);
    }

    public void izmeniProizvod(Proizvod proizvod) throws Exception {
        (new IzmeniProizvodSO()).run(proizvod);
    }

    public ArrayList<Kupac> vratiSveKupce() throws Exception {
        VratiKupceSO so = new VratiKupceSO();
        so.run(new Kupac());
        return so.getLista();
    }

    public ArrayList<Proizvod> vratiSveProizvode() throws Exception {
        VratiProizvodeSO so = new VratiProizvodeSO();
        so.run(new Proizvod());
        return so.getLista();
    }

    public ArrayList<Sirovina> vratiSveSirovine() throws Exception {
        VratiSirovineSO so = new VratiSirovineSO();
        so.run(new Sirovina());
        return so.getLista();
    }
     public ArrayList<StavkaProizvoda> vratiSveStavkeProizvoda(Proizvod proizvod) throws Exception {
         StavkaProizvoda sp = new StavkaProizvoda();
         sp.setProizvod(proizvod);
         VratiStavkeProizvodaSO so=new VratiStavkeProizvodaSO();
         so.run(sp);
         return so.getLista();
     }


    public void logout(Zaposleni ulogovani) {
        ulogovaniZaposleni.remove(ulogovani);
    }

   
    

}
