/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package niti;

import kontroler.Kontroler;
import domen.Kupac;
import domen.Proizvod;
import domen.Racun;
import domen.Zaposleni;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import transfer.Zahtev;
import transfer.Odgovor;
import operacije.VrstaOdgovora;
import operacije.Operacije;

/**
 *
 * @author PC
 */
public class ObradaKlijentskihZahteva extends Thread {

    private Socket socket;

    ObradaKlijentskihZahteva(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try {
            while (!socket.isClosed()) {
                ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
                Zahtev zahtev = (Zahtev) in.readObject();
                Odgovor odgovor = obradaZahteva(zahtev);
                ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
                out.writeObject(odgovor);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Odgovor obradaZahteva(Zahtev zahtev) {
        Odgovor odgovor = new Odgovor(null, null, VrstaOdgovora.Uspesno);
        try {
            switch (zahtev.getOperacija()) {
                case Operacije.DODAJ_KUPCA:
                    Kontroler.getInstance().dodajKupca((Kupac) zahtev.getObjekat());
                    break;
                case Operacije.DODAJ_PROIZVOD:
                    Kontroler.getInstance().dodajProizvod((Proizvod) zahtev.getObjekat());
                    break;
                case Operacije.DODAJ_RACUN:
                    Kontroler.getInstance().dodajRacun((Racun) zahtev.getObjekat());
                    break;
                case Operacije.OBRISI_KUPCA:
                    Kontroler.getInstance().obrisiKupca((Kupac) zahtev.getObjekat());
                    break;
                case Operacije.OBRISI_PROIZVOD:
                    Kontroler.getInstance().obrisiProizvod((Proizvod) zahtev.getObjekat());
                    break;
                case Operacije.IZMENI_KUPCA:
                    Kontroler.getInstance().izmeniKupca((Kupac) zahtev.getObjekat());
                    break;
                case Operacije.IZMENI_PROIZVOD:
                    Kontroler.getInstance().izmeniProizvod((Proizvod) zahtev.getObjekat());
                    break;
                case Operacije.VRATI_SVE_KUPCE:
                    odgovor.setObjekat(Kontroler.getInstance().vratiSveKupce());
                    break;
                case Operacije.VRATI_SVE_PROIZVODE:
                    odgovor.setObjekat(Kontroler.getInstance().vratiSveProizvode());
                    break;
                case Operacije.VRATI_SVE_SIROVINE:
                    odgovor.setObjekat(Kontroler.getInstance().vratiSveSirovine());
                    break;
                case Operacije.VRATI_SVE_SIAVKE_PROIZVODA:
                    odgovor.setObjekat(Kontroler.getInstance().vratiSveStavkeProizvoda((Proizvod)zahtev.getObjekat()));
                    break;
                case Operacije.LOGIN:
                    Zaposleni zaposleni = (Zaposleni) zahtev.getObjekat();
                    Zaposleni ulogovani = Kontroler.getInstance().login(zaposleni);
                    odgovor.setObjekat(ulogovani);
                    break;
                case Operacije.LOGOUT:
                    Zaposleni trenutnoUlogovani = (Zaposleni) zahtev.getObjekat();
                    Kontroler.getInstance().logout(trenutnoUlogovani);
                    break;
                default:
                    return null;
            }
        } catch (Exception ex) {
            odgovor.setVrstaOdgovora(VrstaOdgovora.Greska);
            odgovor.setGreska(ex);
        }
        return odgovor;
    }

}
