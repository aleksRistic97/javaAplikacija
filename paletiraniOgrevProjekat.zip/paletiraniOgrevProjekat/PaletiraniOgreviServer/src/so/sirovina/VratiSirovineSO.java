/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package so.sirovina;

import db.DBBroker;
import domen.AbstractDomainObject;
import domen.Sirovina;
import java.util.ArrayList;
import so.AbstractSO;

/**
 *
 * @author PC
 */
public class VratiSirovineSO extends AbstractSO {

    private ArrayList<Sirovina> lista;

    @Override
    protected void validate(AbstractDomainObject ado) throws Exception {
        if (!(ado instanceof Sirovina)) {
            throw new Exception("Prosledjeni objekat nije instanca klase Sirovina!");
        }
    }

    @Override
    protected void execute(AbstractDomainObject ado) throws Exception {
        ArrayList<AbstractDomainObject> sirovine = DBBroker.getInstance().select(ado);
        lista = (ArrayList<Sirovina>) (ArrayList<?>) sirovine;
    }

    public ArrayList<Sirovina> getLista() {
        return lista;
    }

}
