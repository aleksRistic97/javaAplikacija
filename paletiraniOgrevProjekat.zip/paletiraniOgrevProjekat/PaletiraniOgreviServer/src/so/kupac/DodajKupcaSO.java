/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package so.kupac;

import db.DBBroker;
import domen.AbstractDomainObject;
import domen.Kupac;
import java.util.ArrayList;
import so.AbstractSO;

/**
 *
 * @author PC
 */
public class DodajKupcaSO extends AbstractSO {

    @Override
    protected void validate(AbstractDomainObject ado) throws Exception {
        if (!(ado instanceof Kupac)) {
            throw new Exception("Prosledjeni objekat nije instanca klase Kupac!");
        }

        Kupac k = (Kupac) ado;

        if (k.getPIB().length() != 10) {
            throw new Exception("PIB mora imati tacno 10 cifara!");
        }

        for (int i = 0; i < k.getPIB().length(); i++) {
            if (Character.isLetter(k.getPIB().charAt(i))) {
                throw new Exception("PIB mora imati samo cifre!");
            }
        }

        if (k.getMaticniBroj().length() != 10) {
            throw new Exception("Maticni broj mora imati tacno 10 cifara!");
        }

        for (int i = 0; i < k.getMaticniBroj().length(); i++) {
            if (Character.isLetter(k.getMaticniBroj().charAt(i))) {
                throw new Exception("Maticni broj mora imati samo cifre!");
            }
        }

        ArrayList<Kupac> kupci = (ArrayList<Kupac>) (ArrayList<?>) DBBroker.getInstance().select(ado);

        for (Kupac kupac : kupci) {
            if (kupac.getNaziv().equals(k.getNaziv())) {
                throw new Exception("Kupac sa ovim nazivom vec postoji!");
            }
            if (kupac.getBrojTelefona().equals(k.getBrojTelefona())) {
                throw new Exception("Kupac sa ovim brojem telefona vec postoji!");
            }
        }

    }

    @Override
    protected void execute(AbstractDomainObject ado) throws Exception {
        DBBroker.getInstance().insert(ado);
    }

}
