/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package so.login;

import kontroler.Kontroler;
import db.DBBroker;
import domen.AbstractDomainObject;
import domen.Zaposleni;
import java.util.ArrayList;
import so.AbstractSO;

/**
 *
 * @author PC
 */
public class LoginSO extends AbstractSO {

    Zaposleni ulogovani;

    @Override
    protected void validate(AbstractDomainObject ado) throws Exception {
        if (!(ado instanceof Zaposleni)) {
            throw new Exception("Prosledjeni objekat nije instanca klase Zaposleni!");
        }

        Zaposleni z = (Zaposleni) ado;

        for (Zaposleni zaposleni : Kontroler.getInstance().vratiUlogovanogZaposlenog()) {
            if (zaposleni.getUsername().equals(z.getUsername())) {
                throw new Exception("Ovaj zaposleni je vec ulogovan na sistem!");
            }
        }

    }

    @Override
    protected void execute(AbstractDomainObject ado) throws Exception {

        Zaposleni z = (Zaposleni) ado;

        ArrayList<Zaposleni> listaZaposlenih
                = (ArrayList<Zaposleni>) (ArrayList<?>) DBBroker.getInstance().select(ado);

        for (Zaposleni zaposleni : listaZaposlenih) {
            if (zaposleni.getUsername().equals(z.getUsername())
                    && zaposleni.getPassword().equals(z.getPassword())) {
                ulogovani = zaposleni;
                Kontroler.getInstance().vratiUlogovanogZaposlenog().add(zaposleni);
                return;
            }
        }

        throw new Exception("Ne postoji zaposleni sa tim kredencijalima.");

    }

    public Zaposleni getUlogovani() {
        return ulogovani;
    }

}
