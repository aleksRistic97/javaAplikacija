/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package so.stavkeProizvoda;

import db.DBBroker;
import domen.AbstractDomainObject;
import domen.StavkaProizvoda;
import java.util.ArrayList;
import so.AbstractSO;

/**
 *
 * @author ognje
 */
public class VratiStavkeProizvodaSO extends AbstractSO {

    private ArrayList<StavkaProizvoda> lista;

    @Override
    protected void validate(AbstractDomainObject ado) throws Exception {
        if (!(ado instanceof StavkaProizvoda)) {
            throw new Exception("Prosledjeni objekat nije instanca klase StavkaProizvoda!");
        }

        StavkaProizvoda sp = (StavkaProizvoda) ado;
        // System.out.println(p.getNaziv());
//        if (stavke.isEmpty()) {
//            throw new Exception("Proizvod mora biti sastavljen od barem jedne sirovine!");
//        }

    }

    @Override
    protected void execute(AbstractDomainObject ado) throws Exception {
        StavkaProizvoda sp = (StavkaProizvoda) ado;
        ArrayList<AbstractDomainObject> stavke = DBBroker.getInstance().select(sp);
        lista = (ArrayList<StavkaProizvoda>) (ArrayList<?>) stavke;

    }

    public ArrayList<StavkaProizvoda> getLista() {
        return lista;
    }
}
