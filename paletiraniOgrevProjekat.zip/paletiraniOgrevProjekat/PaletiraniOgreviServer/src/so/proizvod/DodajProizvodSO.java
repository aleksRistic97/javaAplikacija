 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package so.proizvod;

import db.DBBroker;
import domen.AbstractDomainObject;
import domen.Proizvod;
import domen.StavkaProizvoda;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import so.AbstractSO;

/**
 *
 * @author PC
 */
public class DodajProizvodSO extends AbstractSO {

    @Override
    protected void validate(AbstractDomainObject ado) throws Exception {
        if (!(ado instanceof Proizvod)) {
            throw new Exception("Prosledjeni objekat nije instanca klase Proizvod!");
        }

        Proizvod p = (Proizvod) ado;

        if (p.getCenaPoKomadu() < 5000 || p.getCenaPoKomadu() > 25000) {
            throw new Exception("Cena proizvoda mora biti izmedju 5000din i 25000din!");
        }

        if (p.getStavkeProizvoda().isEmpty()) {
            throw new Exception("Proizvod mora biti sastavljen od barem jedne sirovine!");
        }

    }

    @Override
    protected void execute(AbstractDomainObject ado) throws Exception {
        
        PreparedStatement ps = DBBroker.getInstance().insert(ado);
        
        ResultSet tableKeys = ps.getGeneratedKeys();
        tableKeys.next();
        Long proizvodID = tableKeys.getLong(1);
        
        Proizvod p = (Proizvod) ado;
        p.setProizvodID(proizvodID);
        
        for (StavkaProizvoda sp : p.getStavkeProizvoda()) {
             sp.setProizvod(p);
             DBBroker.getInstance().insert(sp);
        }
        
    }

}
