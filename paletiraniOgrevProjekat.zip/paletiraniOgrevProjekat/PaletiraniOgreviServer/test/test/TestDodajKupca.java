/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package test;

import domen.Kupac;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.junit.Test;
import so.kupac.DodajKupcaSO;
import static org.junit.Assert.*;
/**
 *
 * @author PC
 */
public class TestDodajKupca {
    
    public TestDodajKupca() {
    }

     @Test
     public void testDodajKupca() throws Exception {
        DodajKupcaSO so=new DodajKupcaSO();
        Kupac k=new Kupac();
        k.setMaticniBroj("0102997795e");
        k.setPIB("1234567899");
        so.run(k);
     }
     
     @Test
     public void failedTestDodajKupca() {
        try {
            DodajKupcaSO so=new DodajKupcaSO();
            Kupac k=new Kupac();
            k.setMaticniBroj("1234567891011");
            k.setPIB("1234567899");
            so.run(k);
        } catch (Exception ex) {
            System.out.println(ex.getLocalizedMessage());
        }
    }
}
