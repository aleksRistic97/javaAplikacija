/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package test;

import domen.Zaposleni;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.junit.Test;
import static org.junit.Assert.*;
import so.login.LoginSO;

/**
 *
 * @author PC
 */
public class TestLogin {
    
    public TestLogin() {
    }

   
     @Test
     public void testLogin() throws Exception {
         LoginSO so=new LoginSO();
         Zaposleni z=new Zaposleni();
         z.setUsername("aleks");
         z.setPassword("sanja");
         so.run(z);
     }
     
     @Test
     public void testLogin2() {
         //ispravni kredencijali su aleks, aleks,
        try {
            LoginSO so=new LoginSO();
            Zaposleni z=new Zaposleni();
            z.setUsername("aleks");
            z.setPassword("sanja");
            so.run(z);
        } catch (Exception ex) {
            System.out.println(ex.getLocalizedMessage());
        }
      
     }
}
