/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package test;

import domen.Sirovina;
import org.junit.Test;
import static org.junit.Assert.*;
import so.sirovina.VratiSirovineSO;

/**
 *
 * @author PC
 */
public class TestVratiSirovine {
    
    public TestVratiSirovine() {
    }

    
     @Test
     public void testVratiSirovine() throws Exception {
         VratiSirovineSO so=new VratiSirovineSO();
         Sirovina s=new Sirovina();
         so.run(null);
         assertNotNull("U bazi se nalaze sirovine.", so.getLista());
         
     }
}
