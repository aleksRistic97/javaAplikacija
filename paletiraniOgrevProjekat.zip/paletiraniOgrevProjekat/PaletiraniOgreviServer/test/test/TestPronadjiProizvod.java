/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package test;

import domen.Proizvod;
import domen.Sirovina;
import domen.StavkaProizvoda;
import java.util.ArrayList;
import org.junit.Test;
import static org.junit.Assert.*;
import so.proizvod.VratiProizvodeSO;

/**
 *
 * @author PC
 */
public class TestPronadjiProizvod {
    
    public TestPronadjiProizvod() {
    }

  
     @Test
     public void testPronadjiProizvod() throws Exception {
         boolean postoji=false;
         Proizvod p=new Proizvod();
         p.setNaziv("Daska");
         
         VratiProizvodeSO so=new VratiProizvodeSO();
         so.run(p);
         ArrayList<Proizvod> proizvodi=so.getLista();
         for (Proizvod pro : proizvodi) {
             if((pro.getNaziv().toLowerCase()).equals(p.getNaziv().toLowerCase())){
                 postoji=true;
                 break;
             }
         }
         
         assertEquals("Ovaj proizvod postoji u bazi. ", true, postoji);
         
     
     }
}
